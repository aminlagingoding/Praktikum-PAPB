package com.example.praktikum5

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.praktikum5.screen.AboutScreen
import com.example.praktikum5.screen.DetailScreen
import com.example.praktikum5.screen.HomeScreen
import com.example.praktikum5.screen.ProfileScreen

@Composable
fun NavigationLab() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenDetail = { id ->
                    navController.navigate(Routes.detail(id))
                },
                onOpenAbout = { id ->
                    navController.navigate(Routes.about(id))
                },
                onOpenProfile = {
                    navController.navigate(Routes.PROFILE)
                }
            )
        }
        composable(
            route = Routes.DETAIL,
            arguments = listOf(
                navArgument("studentId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val studentId = backStackEntry.arguments?.getInt("studentId") ?: 0
            DetailScreen(
                studentId = studentId,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.PROFILE) {
            ProfileScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Routes.ABOUT,
            arguments = listOf(
                navArgument("studentId") {
                    type = NavType.IntType
                }
            )
        ) { backStackEntry ->
            val studentId = backStackEntry
                .arguments?.
                getInt("studentId") ?: 0
            AboutScreen(
                studentId = studentId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
